// VOSS Intel — Background Service Worker
// Watches for VOSS app tabs opened with ?voss_import=1
// and injects the relay bridge to hand off conversation data

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (
    changeInfo.status === 'complete' &&
    tab.url &&
    tab.url.includes('app.vossintel.com') &&
    tab.url.includes('voss_import=1')
  ) {
    // Read relay data from extension storage
    chrome.storage.local.get('voss_relay', (result) => {
      if (!result.voss_relay) return;

      const relay = result.voss_relay;

      // Guard: ignore stale data older than 5 minutes
      if (Date.now() - relay.timestamp > 5 * 60 * 1000) {
        chrome.storage.local.remove('voss_relay');
        return;
      }

      // Inject script into the VOSS app tab that writes to localStorage
      chrome.scripting.executeScript({
        target: { tabId },
        func: (relayData) => {
          try {
            localStorage.setItem('voss_extension_relay', JSON.stringify(relayData));
            window.dispatchEvent(new CustomEvent('voss_extension_data', { detail: relayData }));
          } catch(e) {
            console.error('[VOSS Bridge] Failed to write relay:', e);
          }
        },
        args: [relay]
      });

      // Clear from extension storage — one time use
      chrome.storage.local.remove('voss_relay');
    });
  }
});
