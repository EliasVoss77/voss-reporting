// VOSS Intel — Content Script
// Detects platform, extracts conversation, responds to popup requests

(function () {
  'use strict';

  // ─── PLATFORM DETECTION ───────────────────────────────────────────────────
  const hostname = window.location.hostname;
  const pathname = window.location.pathname;

  function detectPlatform() {
    if (hostname.includes('claude.ai'))               return 'claude';
    if (hostname.includes('chat.openai.com'))         return 'chatgpt';
    if (hostname.includes('chatgpt.com'))             return 'chatgpt';
    if (hostname.includes('gemini.google.com'))       return 'gemini';
    if (hostname.includes('copilot.microsoft.com'))   return 'copilot';
    if (hostname.includes('bing.com'))                return 'copilot';
    if (hostname.includes('perplexity.ai'))           return 'perplexity';
    if (hostname.includes('grok.com'))                return 'grok';
    if (hostname.includes('x.com') && pathname.startsWith('/i/grok')) return 'grok';

    return 'unknown';
  }

  const platform = detectPlatform();

  // ─── EXTRACTORS ───────────────────────────────────────────────────────────

  function extractClaude() {
    const messages = [];

    const humanSelectors = [
      '[data-testid="human-turn"]',
      '.font-user-message',
      '[class*="human-turn"]',
      'div[class*="HumanTurn"]'
    ];

    const aiSelectors = [
      '[data-testid="ai-turn"]',
      '.font-claude-message',
      '[class*="ai-turn"]',
      'div[class*="AITurn"]'
    ];

    let humanEls = [];
    let aiEls = [];

    for (const sel of humanSelectors) {
      humanEls = Array.from(document.querySelectorAll(sel));
      if (humanEls.length > 0) break;
    }

    for (const sel of aiSelectors) {
      aiEls = Array.from(document.querySelectorAll(sel));
      if (aiEls.length > 0) break;
    }

    if (humanEls.length > 0 || aiEls.length > 0) {
      const allTurns = [
        ...humanEls.map(el => ({ el, role: 'Human' })),
        ...aiEls.map(el => ({ el, role: 'Assistant' }))
      ].sort((a, b) => {
        const pos = a.el.compareDocumentPosition(b.el);
        return pos & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : 1;
      });

      allTurns.forEach(({ el, role }) => {
        const text = el.innerText?.trim();
        if (text && text.length > 1) messages.push(`${role}: ${text}`);
      });

      if (messages.length > 0) return messages.join('\n\n');
    }

    const fallbackEls = document.querySelectorAll(
      'p, [class*="message"], [class*="Message"], [class*="turn"], [class*="Turn"]'
    );
    fallbackEls.forEach(el => {
      const text = el.innerText?.trim();
      if (text && text.length > 10 && !messages.includes(text)) {
        messages.push(text);
      }
    });

    return messages.join('\n\n');
  }

  function extractChatGPT() {
    const messages = [];

    const messageEls = document.querySelectorAll('[data-message-author-role]');

    if (messageEls.length > 0) {
      messageEls.forEach(el => {
        const role = el.getAttribute('data-message-author-role');
        const label = role === 'user' ? 'Human' : 'Assistant';
        const text = el.innerText?.trim();
        if (text && text.length > 1) {
          messages.push(`${label}: ${text}`);
        }
      });
      return messages.join('\n\n');
    }

    const turns = document.querySelectorAll(
      '.text-message, [class*="ConversationItem"], .group'
    );
    turns.forEach(el => {
      const isUser = el.classList.contains('dark:bg-gray-800') ||
                     el.querySelector('[class*="user"]') !== null;
      const label = isUser ? 'Human' : 'Assistant';
      const text = el.innerText?.trim();
      if (text && text.length > 5) messages.push(`${label}: ${text}`);
    });

    return messages.join('\n\n');
  }

  function extractGemini() {
    const messages = [];

    const userEls = document.querySelectorAll(
      'user-query, [class*="user-query"], .user-message, [data-turn-role="user"]'
    );
    const modelEls = document.querySelectorAll(
      'model-response, [class*="model-response"], .model-message, [data-turn-role="model"]'
    );

    if (userEls.length > 0 || modelEls.length > 0) {
      const allTurns = [
        ...Array.from(userEls).map(el => ({ el, role: 'Human' })),
        ...Array.from(modelEls).map(el => ({ el, role: 'Assistant' }))
      ].sort((a, b) => {
        const pos = a.el.compareDocumentPosition(b.el);
        return pos & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : 1;
      });

      allTurns.forEach(({ el, role }) => {
        const text = el.innerText?.trim();
        if (text && text.length > 1) messages.push(`${role}: ${text}`);
      });

      if (messages.length > 0) return messages.join('\n\n');
    }

    const conversationEls = document.querySelectorAll(
      '.conversation-turn, [class*="message-content"], .response-container'
    );
    conversationEls.forEach((el, i) => {
      const text = el.innerText?.trim();
      if (text && text.length > 10) {
        const label = i % 2 === 0 ? 'Human' : 'Assistant';
        messages.push(`${label}: ${text}`);
      }
    });

    return messages.join('\n\n');
  }

  function extractCopilot() {
    const messages = [];

    const userEls = document.querySelectorAll(
      '[data-testid="user-message"], .user-message, cib-message[source="user"], [class*="user-bubble"]'
    );
    const botEls = document.querySelectorAll(
      '[data-testid="bot-message"], .bot-message, cib-message[source="bot"], [class*="bot-bubble"]'
    );

    if (userEls.length > 0 || botEls.length > 0) {
      const allTurns = [
        ...Array.from(userEls).map(el => ({ el, role: 'Human' })),
        ...Array.from(botEls).map(el => ({ el, role: 'Assistant' }))
      ].sort((a, b) => {
        const pos = a.el.compareDocumentPosition(b.el);
        return pos & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : 1;
      });

      allTurns.forEach(({ el, role }) => {
        const text = el.innerText?.trim();
        if (text && text.length > 1) messages.push(`${role}: ${text}`);
      });

      if (messages.length > 0) return messages.join('\n\n');
    }

    const cibChat = document.querySelector('cib-serp');
    if (cibChat?.shadowRoot) {
      const shadowMessages = cibChat.shadowRoot.querySelectorAll('cib-conversation');
      shadowMessages.forEach(el => {
        const text = el.innerText?.trim();
        if (text && text.length > 10) messages.push(text);
      });
    }

    return messages.join('\n\n');
  }

  function extractPerplexity() {
    const messages = [];

    const queryEls = document.querySelectorAll(
      '[class*="query"], .query-text, [data-testid="query"], h2[class*="text"]'
    );
    const answerEls = document.querySelectorAll(
      '[class*="answer"], .prose, [class*="markdown"], [data-testid="answer"]'
    );

    if (queryEls.length > 0 || answerEls.length > 0) {
      const allTurns = [
        ...Array.from(queryEls).map(el => ({ el, role: 'Human' })),
        ...Array.from(answerEls).map(el => ({ el, role: 'Assistant' }))
      ].sort((a, b) => {
        const pos = a.el.compareDocumentPosition(b.el);
        return pos & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : 1;
      });

      allTurns.forEach(({ el, role }) => {
        const text = el.innerText?.trim();
        if (text && text.length > 5) messages.push(`${role}: ${text}`);
      });

      if (messages.length > 0) return messages.join('\n\n');
    }

    const sections = document.querySelectorAll('section, article, [class*="thread"]');
    sections.forEach((el, i) => {
      const text = el.innerText?.trim();
      if (text && text.length > 20) {
        const label = i % 2 === 0 ? 'Human' : 'Assistant';
        messages.push(`${label}: ${text}`);
      }
    });

    return messages.join('\n\n');
  }



  function extractGrok() {
    const messages = [];

    // Grok uses message bubbles with role attributes or class-based structure
    // Primary selectors for grok.com
    const userEls = document.querySelectorAll(
      '[data-testid="userMessage"], [class*="user-message"], [class*="UserMessage"], [class*="human-message"]'
    );
    const aiEls = document.querySelectorAll(
      '[data-testid="assistantMessage"], [data-testid="grokMessage"], [class*="assistant-message"], [class*="AssistantMessage"], [class*="grok-message"], [class*="GrokMessage"]'
    );

    if (userEls.length > 0 || aiEls.length > 0) {
      const allTurns = [
        ...Array.from(userEls).map(el => ({ el, role: 'Human' })),
        ...Array.from(aiEls).map(el => ({ el, role: 'Assistant' }))
      ].sort((a, b) => {
        const pos = a.el.compareDocumentPosition(b.el);
        return pos & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : 1;
      });

      allTurns.forEach(({ el, role }) => {
        const text = el.innerText?.trim();
        if (text && text.length > 1) messages.push(`${role}: ${text}`);
      });

      if (messages.length > 0) return messages.join('\n\n');
    }

    // Fallback — Grok's conversation container
    const conversationEl = document.querySelector(
      '[class*="conversation"], [class*="Conversation"], main'
    );
    if (conversationEl) {
      // Look for alternating message blocks within the conversation
      const msgBlocks = conversationEl.querySelectorAll(
        '[class*="message"], [class*="Message"], [class*="bubble"], [class*="Bubble"]'
      );
      msgBlocks.forEach((el, i) => {
        const text = el.innerText?.trim();
        if (text && text.length > 5) {
          const label = i % 2 === 0 ? 'Human' : 'Assistant';
          messages.push(`${label}: ${text}`);
        }
      });
    }

    return messages.join('\n\n');
  }

  // ─── MAIN EXTRACT FUNCTION ────────────────────────────────────────────────

  function extractConversation() {
    let text = '';

    try {
      switch (platform) {
        case 'claude':      text = extractClaude();      break;
        case 'chatgpt':     text = extractChatGPT();     break;
        case 'gemini':      text = extractGemini();      break;
        case 'copilot':     text = extractCopilot();     break;
        case 'perplexity':  text = extractPerplexity();  break;
        case 'grok':        text = extractGrok();        break;
        default:            text = '';
      }
    } catch (err) {
      console.error('[VOSS] Extraction error:', err);
      text = '';
    }

    text = text
      .replace(/\n{3,}/g, '\n\n')
      .replace(/[ \t]+/g, ' ')
      .trim();

    return text;
  }

  function countMessages(text) {
    if (!text) return 0;
    const humanCount = (text.match(/^Human:/gm) || []).length;
    const assistantCount = (text.match(/^Assistant:/gm) || []).length;
    return humanCount + assistantCount;
  }

  // ─── MESSAGE LISTENER ─────────────────────────────────────────────────────

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === 'VOSS_GET_STATUS') {
      const preview = extractConversation();
      const msgCount = countMessages(preview);
      sendResponse({
        platform,
        supported: platform !== 'unknown',
        messageCount: msgCount,
        charCount: preview.length,
        hasContent: preview.length > 50
      });
      return true;
    }

    if (message.action === 'VOSS_EXTRACT') {
      const conversation = extractConversation();
      sendResponse({
        platform,
        conversation,
        messageCount: countMessages(conversation),
        charCount: conversation.length,
        success: conversation.length > 50
      });
      return true;
    }
  });

})();
