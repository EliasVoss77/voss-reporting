// ─── VOSS EXTENSION RELAY ───────────────────────────────────────────────────
// Add this script block to index.html just before the closing </script> tag
// It listens for data injected by the browser extension and auto-fills the form

function handleExtensionRelay(relay) {
  if (!relay || !relay.conversation) return;
  if (!relay.source === 'extension') return;

  // Guard: ignore stale relays (older than 5 minutes)
  if (Date.now() - relay.timestamp > 5 * 60 * 1000) {
    localStorage.removeItem('voss_extension_relay');
    return;
  }

  // Wait for the app to be in the authenticated + ready state
  const applyRelay = () => {
    const textarea = document.getElementById('rep-issue');
    const nameField = document.getElementById('rep-name');
    const deptField = document.getElementById('rep-department');

    if (!textarea) return; // App not ready yet

    // Pre-fill the form
    if (relay.conversation) textarea.value = relay.conversation;
    if (relay.name && nameField) nameField.value = relay.name;
    if (relay.department && deptField) deptField.value = relay.department;

    // Show a friendly status message
    const platformNames = {
      claude: 'Claude', chatgpt: 'ChatGPT', gemini: 'Gemini',
      copilot: 'Copilot', perplexity: 'Perplexity'
    };
    const platformLabel = platformNames[relay.platform] || relay.platform || 'AI platform';
    setStatus(`✅ Conversation imported from ${platformLabel} — click VOSS Value Report to analyze`, 'success');

    // Visual feedback on the upload zone
    const zone = document.getElementById('upload-zone');
    const uploadStatus = document.getElementById('upload-status');
    if (zone && uploadStatus) {
      zone.classList.add('success');
      uploadStatus.textContent = `✓ Imported from ${platformLabel} via VOSS Extension — ${relay.conversation.length.toLocaleString()} characters`;
    }

    // Clean up
    localStorage.removeItem('voss_extension_relay');
    history.replaceState({}, '', window.location.pathname); // strip ?voss_import param
  };

  // If app is loaded and user is authenticated, apply immediately
  // Otherwise wait for auth state to resolve
  if (currentUser) {
    applyRelay();
  } else {
    // Poll until auth resolves (max 10 seconds)
    let attempts = 0;
    const poll = setInterval(() => {
      attempts++;
      if (currentUser) {
        clearInterval(poll);
        applyRelay();
      } else if (attempts > 20) {
        clearInterval(poll);
      }
    }, 500);
  }

  // Clean relay from localStorage regardless
  setTimeout(() => localStorage.removeItem('voss_extension_relay'), 30000);
}

// ─── Entry points ─────────────────────────────────────────────────────────

// 1. Check on page load (background script may have already written the relay)
(function checkRelayOnLoad() {
  const params = new URLSearchParams(window.location.search);
  if (!params.has('voss_import')) return;

  // Wait briefly for background script to inject the relay
  setTimeout(() => {
    try {
      const raw = localStorage.getItem('voss_extension_relay');
      if (raw) handleExtensionRelay(JSON.parse(raw));
    } catch (e) {
      console.error('[VOSS] Relay parse error:', e);
    }
  }, 800);
})();

// 2. Listen for the custom event fired by the background bridge
window.addEventListener('voss_extension_data', (e) => {
  if (e.detail) handleExtensionRelay(e.detail);
});
