# VOSS Intel — Browser Extension

Captures AI conversations from Claude, ChatGPT, Gemini, Copilot, and Perplexity
and sends them to the VOSS Intel app for instant value analysis.

---

## File Structure

```
voss-extension/
├── manifest.json           ← Chrome (MV3)
├── manifest.firefox.json   ← Firefox (MV2) — rename to manifest.json for FF build
├── background.js           ← Service worker: tab creation + data relay
├── content.js              ← Injected into AI platforms: DOM extraction
├── popup.html              ← Toolbar popup UI
├── popup.js                ← Popup logic
├── app-relay-snippet.js    ← CODE TO ADD to index.html (see below)
└── icons/
    ├── icon16.png
    ├── icon48.png
    └── icon128.png
```

---

## Step 1 — Add Icons

Create or export the VOSS logo as PNG at three sizes:
- `icons/icon16.png`   — 16×16px
- `icons/icon48.png`   — 48×48px
- `icons/icon128.png`  — 128×128px

The accent green (#00e57a) on dark background (#080b0f) works well.

---

## Step 2 — Add Relay Code to index.html

Open `index.html` and paste the entire contents of `app-relay-snippet.js`
**inside the existing `<script>` tag, just before the closing `}`** of the
main script block (before `</script>`).

This lets the VOSS app receive data from the extension when a new tab opens.

---

## Step 3 — Also Update the "Coming Soon" Banner in index.html

Find this block in index.html:
```html
<div class="share-coming-soon">
  <span class="share-coming-icon">🔗</span>
  <span class="share-coming-text">One-click import via the VOSS Browser Extension — no copy/paste needed</span>
  <span class="share-coming-badge">Coming Soon</span>
</div>
```

Change the badge from "Coming Soon" to "Available Now":
```html
<span class="share-coming-badge" style="background:rgba(0,229,122,0.1);color:var(--accent);border-color:rgba(0,229,122,0.3);">Available Now</span>
```

---

## Step 4 — Load in Chrome (Developer Mode)

1. Go to `chrome://extensions`
2. Enable **Developer Mode** (top right toggle)
3. Click **Load Unpacked**
4. Select the `voss-extension/` folder
5. Pin the extension to your toolbar

---

## Step 5 — Load in Firefox

1. Rename `manifest.firefox.json` → `manifest.json` (backup the Chrome one first)
2. Go to `about:debugging`
3. Click **This Firefox** → **Load Temporary Add-on**
4. Select any file inside the `voss-extension/` folder

For permanent Firefox install, submit to addons.mozilla.org.

---

## How It Works

1. User navigates to Claude, ChatGPT, Gemini, Copilot, or Perplexity
2. Clicks the VOSS toolbar icon
3. Popup shows: platform name, message count, character count
4. User optionally adds their name and department
5. Clicks **Send to VOSS**
6. Extension extracts the full conversation from the page DOM
7. Stores it in `chrome.storage.local` as a one-time relay
8. Opens `app.vossintel.com?voss_import=1&platform=claude` in a new tab
9. Background script injects a bridge into the new tab
10. Bridge reads from storage, writes to `localStorage`, fires a custom event
11. VOSS app detects the event, auto-fills the transcript field and name/dept
12. User clicks **VOSS Value Report** — done

---

## Platform Extraction Notes

Each platform uses different DOM structures. The content script tries
structured selectors first, then falls back to heuristic extraction.

| Platform   | Primary Selectors                          |
|------------|--------------------------------------------|
| Claude     | `[data-testid="human-turn"]`, `.font-claude-message` |
| ChatGPT    | `[data-message-author-role]`               |
| Gemini     | `user-query`, `model-response`             |
| Copilot    | `[data-testid="user-message"]`, `cib-message` |
| Perplexity | `[class*="query"]`, `.prose`               |

If a platform updates their DOM, update the selectors in `content.js`.

---

## Chrome Web Store Submission (When Ready)

1. Zip the `voss-extension/` folder (not the folder itself, the contents)
2. Go to the [Chrome Developer Dashboard](https://chrome.google.com/webstore/devconsole)
3. Pay one-time $5 developer fee if not already registered
4. Upload zip, fill in store listing, submit for review (~3-5 business days)

Suggested store description:
> "VOSS Intel captures your AI conversations from Claude, ChatGPT, Gemini, Copilot,
> and Perplexity with one click — no copy/paste or file export needed. Opens your
> conversation directly in the VOSS Intel app for instant AI value analysis,
> time tracking, and business ROI reporting."

---

## Future Enhancements (Post-Launch)

- Auto-detect conversation end and offer to capture
- Badge showing message count on the toolbar icon
- Silent background capture for Enterprise tier
- Support for custom/self-hosted LLM interfaces
- Notion, Slack, Teams integration
