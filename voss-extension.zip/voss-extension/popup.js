// VOSS Intel — Popup Script

const PLATFORMS = {
  claude:     { name: 'Claude',      icon: '🟠', url: 'claude.ai' },
  chatgpt:    { name: 'ChatGPT',     icon: '🟢', url: 'chat.openai.com' },
  gemini:     { name: 'Gemini',      icon: '🔵', url: 'gemini.google.com' },
  copilot:    { name: 'Copilot',     icon: '🟣', url: 'copilot.microsoft.com' },
  perplexity: { name: 'Perplexity',  icon: '⚡', url: 'perplexity.ai' },
  grok:       { name: 'Grok',         icon: '𝕏',  url: 'grok.com' },
};

let activeTabId = null;

function setStatus(msg, type = '') {
  const el = document.getElementById('status-msg');
  el.textContent = msg;
  el.className = 'status-msg ' + type;
}

function showState(state) {
  ['detecting', 'supported', 'unsupported', 'nocontent'].forEach(s => {
    document.getElementById('state-' + s).style.display = s === state ? 'block' : 'none';
  });
}

function formatNumber(n) {
  if (n >= 1000) return (n / 1000).toFixed(1) + 'k';
  return n.toString();
}

async function detectPage() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id) { showState('unsupported'); return; }
    activeTabId = tab.id;

    const response = await chrome.tabs.sendMessage(tab.id, { action: 'VOSS_GET_STATUS' });

    if (!response || !response.supported) { showState('unsupported'); return; }
    if (!response.hasContent) { showState('nocontent'); return; }

    const platform = PLATFORMS[response.platform] || { name: response.platform, icon: '🤖', url: '' };
    document.getElementById('p-icon').textContent = platform.icon;
    document.getElementById('p-name').textContent = platform.name;
    document.getElementById('p-url').textContent = tab.url?.replace('https://', '').split('/')[0] || platform.url;
    document.getElementById('s-messages').textContent = response.messageCount || '—';
    document.getElementById('s-chars').textContent = formatNumber(response.charCount || 0);

    showState('supported');

    chrome.storage.local.get(['voss_name', 'voss_dept'], (result) => {
      if (result.voss_name) document.getElementById('field-name').value = result.voss_name;
      if (result.voss_dept) document.getElementById('field-dept').value = result.voss_dept;
    });

  } catch (err) {
    console.error('[VOSS Popup] detectPage error:', err);
    showState('unsupported');
  }
}

async function sendToVoss() {
  const btn = document.getElementById('send-btn');
  const name = document.getElementById('field-name').value.trim();
  const dept = document.getElementById('field-dept').value.trim();

  chrome.storage.local.set({ voss_name: name, voss_dept: dept });

  btn.disabled = true;
  btn.textContent = '⏳ Extracting...';
  btn.classList.add('loading');
  setStatus('Reading conversation...', 'loading');

  try {
    if (!activeTabId) throw new Error('No active tab — close and reopen the popup');

    const response = await chrome.tabs.sendMessage(activeTabId, { action: 'VOSS_EXTRACT' });

    if (!response?.success || !response.conversation) {
      throw new Error('Could not extract conversation — scroll through the full chat first');
    }

    setStatus('Opening VOSS...', 'loading');
    btn.textContent = '🚀 Opening VOSS...';

    // Write relay directly from popup — no background worker needed
    await chrome.storage.local.set({
      voss_relay: {
        conversation: response.conversation,
        platform: response.platform,
        name: name || '',
        department: dept || '',
        timestamp: Date.now(),
        source: 'extension'
      }
    });

    // Open VOSS tab directly from popup
    const vossUrl = 'https://app.vossintel.com?voss_import=1&platform=' + encodeURIComponent(response.platform);
    await chrome.tabs.create({ url: vossUrl });

    setStatus('✓ VOSS opened — ready to analyze!', 'success');
    btn.textContent = '✓ Done!';
    btn.style.background = 'rgba(0,229,122,0.2)';
    btn.style.color = 'var(--accent)';
    setTimeout(() => window.close(), 1500);

  } catch (err) {
    console.error('[VOSS Popup] error:', err);
    setStatus('✕ ' + err.message, 'error');
    btn.disabled = false;
    btn.textContent = '⚡ Send to VOSS';
    btn.classList.remove('loading');
    btn.style.background = '';
    btn.style.color = '';
  }
}

detectPage();

// Wire up button via addEventListener (required by MV3 CSP — no inline onclick allowed)
document.addEventListener('DOMContentLoaded', () => {
  document.getElementById('send-btn').addEventListener('click', sendToVoss);
});
